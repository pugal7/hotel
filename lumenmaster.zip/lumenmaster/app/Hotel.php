<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hotel extends Model
{
    //
    protected $table = 'hotel_package';
    protected $fillable = ['name','price','duration','valid_from','valid_to','description'];
}
