<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Hotel;
use Auth;

class HotelController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        
        $hotel = Hotel::all();
        return response()->json(['success' => 'success','data' => $hotel]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         
         if($request->name=="" || $request->price=="" || $request->duration=="" || $request->valid_from=="" || $request->valid_to=="" || $request->description==""){
            return response()->json(['success' => 'error', 'msg' => 'All fields are mandatory']);
         }

         $hotels = new Hotel;
         $hotel = $hotels->where(['name' => $request->name])->first();
         if (empty($hotel)) {
             $hotels->name = $request->name;
             $hotels->price = $request->price;
             $hotels->duration = $request->duration;
             $hotels->valid_from = $request->valid_from;
             $hotels->valid_to = $request->valid_to;
             $hotels->description = $request->description;
             $result = $hotels->save();

            if($result == 1){
                return response()->json(['success' => 'success', 'msg' => 'Hotel packages inserted successfully']);
            }else{
                return response()->json(['success' => 'Failed', 'msg' => 'Something went wrong']);
            }
         } else {
            return response()->json(['success' => 'Failed', 'msg' => 'Hotel name already exists']);
         }


       

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $todo = Hotel::where('id', $id)->get();
        return response()->json($todo);
        
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'required',
            'price' => 'required',
            'duration' => 'required',
            'valid_from' => 'required',
            'valid_to' => 'required',
            'description' => 'required'
         ]);
        $hotel = Hotel::find($id);
        if($hotel->fill($request->all())->save()){
           return response()->json(['success' => 'success', 'msg' => 'Record updated successfully']);
        }
        return response()->json(['success' => 'Failed', 'msg' => 'Something went wrong']);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        if(Hotel::destroy($id)){
             return response()->json(['success' => 'success', 'msg' => 'Record deleted successfully']);
        }
    }
}
