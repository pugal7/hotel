# Creating REST API With Lumen

# Run the database migrations (Set the database connection in .env before migrating)

1. php artisan migrate

2. php -S localhost:8000 -t public

      # You can now access the server at http://localhost:8000